# multipart-post CHANGELOG

## v1.0

- First release.

## v1.1

- `encode` autogenerates the boundary by default
